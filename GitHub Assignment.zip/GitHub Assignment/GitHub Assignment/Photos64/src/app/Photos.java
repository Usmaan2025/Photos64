package app;
import controller.LogInController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import model.SceneChange;

/**
 * Main class used to run Photos application
 * @author Usmaan Ilyas and Mazin Hamamou
 */
public class Photos extends Application {

    /**
     * Overridden start method for application
     */
    @Override
    public void start(Stage stage) throws Exception {

        

		SceneChange.readFromFile();
		// Initializes the start scene
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(getClass().getResource("/view/loginScene.fxml"));
		AnchorPane root = (AnchorPane)loader.load();
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.setTitle("Photo Library");
		stage.setResizable(false);  
		stage.show();

        stage.setOnCloseRequest(e -> {
            try {
                SceneChange.writeToFile();
            }
            catch(Exception e2) {};
        });
    }
    
    public static void main(String [] args) {
        launch(args);
    }
    

}
