package model;
import javafx.scene.image.Image;
import java.util.ArrayList;
import java.io.*;
import java.util.*;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;
/**
 * @author Usmaan Ilyas and Mazin Hamamou
 * object that represents a singular photo in an album.
 */
public class Photo implements Serializable {
    
    /**
     * Album that the photo is placed in
     * Every photo object will correspond to some album.
     */
    public Album album;

    /**
	 * Caption that the user chooses to input. 
	 */
	public String caption;

    /**
	 * String representation of the date of the photo
	 */
	public String date;

    /**
	 * LocalDateTime object to keep track of date and time of this photo
	 */
	public LocalDateTime dateAndTime;

    /**
	 * Image object to represent the thumbnail of the photo. 
     * Should not be serialized when saving this photo. 
	 */
	transient public Image thumbnail;
	
	/**
	 * Image object to represent the image when in its actual size. 
     * Should not be serialized when saving this photo
	 */
	transient public Image accSize;

    /**
	 * File object needed to refer to each photo. 
	 */
	public File fileOfPhoto;

    /**
     * List to hold tags for this photo, can be empty. 
     */
    public List<String> listOfTags = new ArrayList<String>();

    /**
     * no args constructor when not all fields are needed
     */
    public Photo() {}

    /**
     * 
     * @param a Album that this photo belongs to
     * @param cap Caption entered by the user, could be blank
     * @param f File that the photo belongs to 
     * @param tags Tags inputted by the user in the form of a list
     * @throws IllegalArgumentException to handle invalid files and albums
     */
    public Photo(Album a, String cap, File f, List<String> tags) throws IllegalArgumentException {
            if(cap != null) caption = cap;
            else caption = "";
            if(!f.exists() || f  == null) {
                throw new IllegalArgumentException("Photo file is invalid");
            }
            if(a == null) {
                throw new IllegalArgumentException("Album is invalid");
            }

            fileOfPhoto = f;
            album = a;

            if(tags != null) {
                listOfTags.addAll(tags);
            }

            dateAndTime = LocalDateTime.ofInstant(Instant.ofEpochSecond(fileOfPhoto.lastModified()/1000), ZoneId.systemDefault());
            
            date = dateAndTime.getMonth() + "/" + dateAndTime.getDayOfMonth() + "/" + dateAndTime.getYear();

            try {
                accSize = new Image(fileOfPhoto.toURI().toString());
                thumbnail = new Image(fileOfPhoto.toURI().toString(), 75, 75, true, true);
            }catch (Exception e) {}

        
    }

    /**
     * Method to get the description to be shown when a photo is displayed.
     * @return String object that contains all necessary info in the description. 
     */
    public String description() {
        StringBuilder desc = new StringBuilder();
        desc.append("Caption: " + caption + "\n");
        desc.append("Date: " + date + "\n");
        if(dateAndTime.getMinute() < 10) {
            desc.append("Time: " + dateAndTime.getHour() + ":0" + dateAndTime.getMinute() + "\n");
        }
        else desc.append("Time: " + dateAndTime.getHour() + ":" + dateAndTime.getMinute() + "\n");

        desc.append("Tags: ");
        for(int i = 0; i < listOfTags.size(); i++) {
            String t = listOfTags.get(i);
            desc.append(t + "; ");
        }
        return desc.toString();
    }
    
    /**
     * Method to return caption when needed for album view
     * @return String object representing the caption for this photo. 
     */
    public String getCaption() {
        return caption;
    }

    /**
     * Creation of a reference photo to hold the values of a photo when a user is in the process of editing 
     * that photo
     * @param f File for the reference photo
     * @param cap Caption for the reference photo
     * @param tags Tags for the reference photo
     * @return A reference photo with information that is updated
     */
    public static Photo refPhoto(File f, String cap, List<String> tags) {
        Photo reference = new Photo();
        reference.fileOfPhoto = f;
        if(cap != null) reference.caption = cap; else reference.caption = "";
        if(tags!= null) reference.listOfTags = tags;
        return reference;
    }

    /**
     * Sets the size and attributes of Image objects since they will not be serialized with the Photo
     */
    public void setImageSize() {
        thumbnail = new Image(fileOfPhoto.toURI().toString(), 75, 75, true, true);
        accSize = new Image(fileOfPhoto.toURI().toString());
    }

    public Photo copyToAlbum(Album a) {
		return new Photo(a, this.caption, this.fileOfPhoto, this.listOfTags);
	}
	

	

	

	

	
	


}
