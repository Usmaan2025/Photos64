package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Album object
 * @author Usmaan Ilyas and Mazin Hamamou
 */

public class Album implements Serializable {
    
    /**
     * number of photos in this album
     */
    public int amountOfPhotos;

    /**
     * List representation of photos in this album
     */
    public List<Photo> photosInAlbum = new ArrayList<Photo> ();

    /**
     * name of this album
     */
    public String name;

    /**
     * date of the earliest photo in String representation
     */
    public String earliestDate;

    /**
     * date of the lates photo in String representation
     */
    public String latestDate;

    /**
     * Constructor for this album class
     * @param n Name of the album
     */
    public Album(String n) {
        name = n;
    }

    /**
     * method to update fields of album object when photos are added or deleted
     */
    public void updateFields() {
		amountOfPhotos = photosInAlbum.size();
		
		if(photosInAlbum.size() > 0) {
			Photo earliest = photosInAlbum.get(0);
			Photo latest = photosInAlbum.get(0);
			for(Photo p : photosInAlbum) {
				if(p.dateAndTime.isBefore(earliest.dateAndTime)) {
					earliest = p;
				}else if(p.dateAndTime.isAfter(latest.dateAndTime)) {
					latest = p;
				}
			}
			earliestDate = earliest.date;
			latestDate = latest.date;
		}else {
			earliestDate = "";
			latestDate = "";
		}
	}

    /**
     * String representation of Album object, returns the name of the album
     */
    public String toString() {
        return name;
    }

}
