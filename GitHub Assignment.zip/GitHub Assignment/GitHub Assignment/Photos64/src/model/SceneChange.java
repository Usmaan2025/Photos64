package model;

import java.io.Serializable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.stage.Stage;

/**
 * Class to handle switching between scenes and storing information
 * @author Usmaan Ilyas and Mazin Hamamou
 */
public class SceneChange implements Serializable {
   

    /**
	 * ArrayList of all users in the app
	 */
	public List<User> users = new ArrayList<User>();

    /**
	 * String to keep the directory of th project
	 */
     public static String projectDir = new File(SceneChange.class.getProtectionDomain().getCodeSource().getLocation().getPath().replaceAll("%20", " "))
    .getParent();

    /**
	 * File that contains the saved data 
	 */
	public static File savedFile =  new File(projectDir + File.separator + "data" + File.separator + "data.dat");

    /**
	 * instance of SceneChange if a particular state needs to be changed. 
	 */
	public static SceneChange ins = new SceneChange();

    /**
	 * User object to track the current user on the app
	 */
	transient public User currUser;

    /**
	 * Album object to track current album in use
	 */
	transient public Album currAlbum;

    /**
	 * Photo object to keep track of photo data while photo is being changed
	 */
	transient public Photo changingPhoto;


    /**
	 * Photo object to keep track of photos while tags are being created or changed
	 */
	transient public Photo tempPhoto;

    /**
	 * Photos that show up after a search
	 */
	transient public List<Photo> results;

    /**
	 * String that has the what the user has searched at a particular moment.
	 */
	transient public String searchText;


    /**
	 * List of photos that are being viewed in slideshow 
	 */
	transient public List<Photo> slideShowList;


    /**
	 * Int that represents the slide a user is on when in slideshow viewing mode
	 */
	transient public int slide;


    /**
     * Constructor for the SceneChange class that itniailizes the user account stock with five photos
     */
    public SceneChange() {
		User u = new User("stock");
		users.add(u);
		Album a = new Album("stock");
		u.albums.add(a);
		try {
			String dirPath = projectDir + File.separator
					+ "data" + File.separator;
			a.photosInAlbum.add(new Photo(a, "Stock 1", new File(dirPath + "pic1.png"), null));
			a.photosInAlbum.add(new Photo(a, "Stock 2", new File(dirPath + "pic2.png"), null));
			a.photosInAlbum.add(new Photo(a, "Stock 3", new File(dirPath + "pic3.png"), null));
			a.photosInAlbum.add(new Photo(a, "Stock 4", new File(dirPath + "pic4.png"), null));
			a.photosInAlbum.add(new Photo(a, "Stock 5", new File(dirPath + "pic5.png"), null));
		}catch(Exception e) {}
	}


    /**
     * Returns the user with the matching name as the paramater
     * @param n the name of the user 
     * @return the user that matches the name, null if no user with that name exists. 
     */
    public User getUser(String n) {

        for(User u: users) {
            if(u.username.equals(n)) return u;
        }
        return null;
    }

    /**
	 * Method to switch scenes
	 * @param o The corresponding controller class that needs to be called
	 * @param b The button that was pressed 
	 * @param fxml The corresponding fxml file of the next scene
	 */
	public static void sceneChanger(Object o ,Button b, String fxml) {
		Stage window = (Stage) b.getScene().getWindow();
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(o.getClass().getResource("/view/" + fxml));
		try {
			window.setScene(new Scene(loader.load()));
		} catch (IOException e) {
			e.printStackTrace();
		}
    }

    	/**
	 * A method to call alerts for various reasons
	 * @param a the type of alert needed for a situation
	 * @param b The Button that resulted in the alert
	 * @param s The text we want to show up. 
	 * @return Returns an Alert object based on the error that was committed
	 */
	public static Alert alert(AlertType a, Button b, String s) {
		Alert alert = new Alert(a);
		alert.initOwner(b.getScene().getWindow());
		alert.setHeaderText(s);
		alert.showAndWait();
		return alert;
	}


    /**
     * Used to save data on the application to the file. 
     * @throws IOException
     * @throws FileNotFoundException
     */
	public static void writeToFile() throws IOException, FileNotFoundException {
		var oos = new ObjectOutputStream(new FileOutputStream(savedFile));
		oos.writeObject(ins);
		oos.close();
	}

    
    /**
	 * Getting data from the save file when reopening the app. 
	 */
	public static void readFromFile() {
		if(!savedFile.exists()) {
			return;
		}
		ObjectInputStream ois;
		try {
			ois = new ObjectInputStream(new FileInputStream(savedFile));
			ins = (SceneChange) ois.readObject();
		} catch(Exception e) { ins = new SceneChange(); return; }
		
		for(User u : ins.users) {
			for(Album a : u.albums) {
				for(Photo p : a.photosInAlbum) {
					p.setImageSize();
				}
			}
		}
		try {
			ois.close();
		} catch (Exception e) {}
	}






}
