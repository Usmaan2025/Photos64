package model;

import java.io.Serializable;
import java.util.List;
import java.util.ArrayList;

/**
 * Class to represent a user object
 * @author Usmaan Ilyas and Mazin Hamamou
 */
public class User implements Serializable {
    /**
	 * Username of the user. 
	 */
	public String username;
	
	/**
	 * List of this users albums
	 */
	public List<Album> albums = new ArrayList<Album>();
	
	/**
	 * List of the users preset tags. 
	 */
	public List<String> presetTags = new ArrayList<String>();
	
	
    /**
	 * User constructor. Sets the username and creates to default values location and person for tags
	 * @param username The user's username.
	 */
	public User(String u) {
		username = u;
		presetTags.add("location");
		presetTags.add("person");
	}
	
	
    
    /**
	 * Checks for the  existence of an album
	 * @param name String name of the album that needs to be checked
	 * @return the album whose name was entered as a parameter. If the album does not exist, null will be returned
	 */
	public Album checkAlbum(String name) {
		for(Album a : albums) {
			if(a.name.equals(name)) {
				return a;
			}
		}
		return null;
	}
	
	/**
	 * Method to get the total number of photos across all albums to know when searching for photos across all albums. 
	 * @return an int being the total count of all photos this user has in every album of theirs. 
	 */
	public int getNumberOfPhotos() {
		int num = 0;
		for(Album a : albums) {
			num += a.photosInAlbum.size();
		}
		return num;
	}
	
	/**
	 * Returns the username of this user.
	 */
	public String toString() {
		return username;
	}
}
