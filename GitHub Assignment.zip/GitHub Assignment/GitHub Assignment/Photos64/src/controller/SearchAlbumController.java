package controller;

import model.SceneChange;
import model.Photo;
import model.Album;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;

/**
 * Controller class for the scene where user creates an album via search results 
 * @author Usmaan Ilyas and Mazin Hamamou
 */
public class SearchAlbumController {
    
    @FXML
    private Button goBackButton;

    @FXML
    private TextField albumNameTextField;

    @FXML
    private Button enterButton;

    /**
     * Handles the event where user presses the goBackButton
     */
    @FXML
    public void goBack(){
        SceneChange.sceneChanger(this, goBackButton, "searchResultsScene.fxml");
    }

    /**
     * Handles the event where user presses the enterButton
     */
    @FXML
    public void enter() {
        String albumName = albumNameTextField.getText();

        if(albumName.equals("")) {
    		SceneChange.alert(AlertType.ERROR, enterButton, "Invalid Album name!");
    	}
        else {
    		Album a = SceneChange.ins.currUser.checkAlbum(albumName);
    		if(a != null) {
    			SceneChange.alert(AlertType.ERROR, enterButton, "You already have an album with that name");
    		}
            else {
    			a = new Album(albumName);
    			for(Photo p : SceneChange.ins.results) {
    				a.photosInAlbum.add(p.copyToAlbum(a));
    			}
    			
                SceneChange.ins.currUser.albums.add(a);
    			SceneChange.ins.searchText = null;
    	    	SceneChange.ins.results = null;
    			SceneChange.sceneChanger(this, enterButton, "albumListScene.fxml");
    		}
    }
    }  
} 
