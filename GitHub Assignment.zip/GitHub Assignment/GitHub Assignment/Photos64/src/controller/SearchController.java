package controller;

import model.Photo;
import model.Album;
import model.SceneChange;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import javafx.fxml.FXML;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;

/**
 * Controller class to deal with the initial search scene
 * @author Usmaan Ilyas and Mazin Hamamou
 */
public class SearchController {
    
    @FXML
    private Button goBackButton;

    @FXML
    private Button searchButton;

    @FXML
    private Button clearButton;

    @FXML
    private TextField searchTextField;

    @FXML
    private DatePicker toDatePicker;

    @FXML
    private DatePicker fromDatePicker;

    /**
     * Handles the event where the goBackButton is pressed
     */
    @FXML
    public void goBack() {
        SceneChange.sceneChanger(this, goBackButton, "albumListScene.fxml");
    }

    /**
     * Handles the event where the clearButton is pressed
     */
    @FXML
    public void clearFields() {
        toDatePicker.setValue(null);
        fromDatePicker.setValue(null);
    }

    /**
     * Handles the event where the searchButton is pressed
     */
    @FXML
    public void search() {
        String text = searchTextField.getText().strip();
    	
        if(!text.matches(".+=.+") && fromDatePicker.getValue() == null && toDatePicker.getValue() == null) {
    		SceneChange.alert(AlertType.ERROR, searchButton, "Invalid entry!");
    		return;
    	}
    	
    	
        List<Photo> searchResults = new ArrayList<Photo>(SceneChange.ins.currUser.getNumberOfPhotos());
    	
    	if(text.matches(".+=.+\\s((AND)|(and))\\s.+=.+")) {
    		String[] checkMatch = text.split("\\s((AND)|(and))\\s");
    		for(Album a : SceneChange.ins.currUser.albums) {
    			
                for(Photo p : a.photosInAlbum) {
    				if(p.listOfTags.contains(checkMatch[0]) && p.listOfTags.contains(checkMatch[1])) {
    					searchResults.add(p);
    				}
    			}
    		}
    	}
        else if(text.matches(".+=.+\\s((OR)|(or))\\s.+=.+")) {
    		String[] checkMatch = text.split("\\s((OR)|(or))\\s");
    		for(Album a : SceneChange.ins.currUser.albums) {
    			for(Photo p : a.photosInAlbum) {
    				if(p.listOfTags.contains(checkMatch[0]) || p.listOfTags.contains(checkMatch[1])) {
    					searchResults.add(p);
    				}
    			}
    		}
    	}
        else if(text.matches(".+=.+")) {
    		for(Album a : SceneChange.ins.currUser.albums) {
    			for(Photo p : a.photosInAlbum) {
    				if(p.listOfTags.contains(text)) {
    					searchResults.add(p);
    				}
    			}
    		}
    	}
        else if(fromDatePicker.getValue() != null || toDatePicker.getValue() != null) {
    		for(Album a : SceneChange.ins.currUser.albums){
    			for(Photo p : a.photosInAlbum) {
    				searchResults.add(p);
    			}
    		}
    	}
        else {
    		SceneChange.alert(AlertType.ERROR, searchButton, "Invalid Entry!"); return;
    	}
    	
    	if(fromDatePicker.getValue() != null) {
    		LocalDateTime from = fromDatePicker.getValue().atStartOfDay();
    		searchResults.removeIf((p) -> p.dateAndTime.isBefore(from));
    	}
    	
        if(toDatePicker.getValue() != null) {
    		LocalDateTime to = toDatePicker.getValue().atTime(23, 59, 59);
    		searchResults.removeIf((p) -> p.dateAndTime.isAfter(to));
    	}
    	
    	SceneChange.ins.searchText = text;
    	SceneChange.ins.results = searchResults;
    	SceneChange.sceneChanger(this, searchButton, "searchResultsScene.fxml");
    }
}
