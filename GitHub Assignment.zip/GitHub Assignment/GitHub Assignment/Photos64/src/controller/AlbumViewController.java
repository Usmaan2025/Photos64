package controller;
import model.Album;
import model.SceneChange;
import model.Photo;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.ImageView;

/**
 * Controller class for when user is viewing the contents of an album
 * @author Usmaan Ilyas and Mazin Hamamou
 */

public class AlbumViewController {
    
    @FXML
    private Label AlbumViewLabel; //handled
    
    @FXML
    private ListView<Photo> photoListView;

    @FXML
    private Button goBackButton; //handled

    @FXML
    private Button addPhotoButton; //handled

    @FXML
    private Button editPhotoButton; //handled
    
    @FXML
    private Button deletePhotoButton; //handled

    @FXML
    private Button movePhotoButton; //handled

    @FXML
    private Button copyPhotoButton; //handled

    @FXML
    private Button slideShowViewButton; //handled


    /**
     * used to view and display the list of photos
     */
    ObservableList<Photo> photoViewList = FXCollections.observableList(SceneChange.ins.currAlbum.photosInAlbum);


    /**
     * initialize method used to set up and correctly display the ListView of photos
     * 
     */
    public void initialize() {
        AlbumViewLabel.setText(SceneChange.ins.currAlbum.name);
       
        photoListView.setItems(photoViewList);
    	photoListView.setCellFactory(pic -> new ListCell<Photo>() {
    		public void updateItem(Photo p, boolean isEmpty) {
    			super.updateItem(p, isEmpty);
    			if(isEmpty) {
    				setText(null);
    				setGraphic(null);
    			}
                else {
    				setText(p.caption + " ");
    				ImageView i = new ImageView();
    				i.setImage(p.thumbnail);
    				setGraphic(i);
    			}
    		}
    	});
    	
    	if(photoViewList.isEmpty()) {
    		deletePhotoButton.setDisable(true);
    		editPhotoButton.setDisable(true);
    		movePhotoButton.setDisable(true);
            copyPhotoButton.setDisable(true);
    		slideShowViewButton.setDisable(true);
    	}
        else {
    		deletePhotoButton.setDisable(false);
    		editPhotoButton.setDisable(false);
    		slideShowViewButton.setDisable(false);
    		movePhotoButton.setDisable(false);
    		photoListView.getSelectionModel().select(0);
    	}


    }

    /**
     * Handles event where user wants to add a picture
     */
    @FXML
    public void addPhoto() {
    	SceneChange.sceneChanger(this, addPhotoButton, "addPhotoScene.fxml");
    }

    /**
     * Handles event where user presses the goBack button
     */
    @FXML
    public void goBack() {
        SceneChange.sceneChanger(this, goBackButton, "albumListScene.fxml");
    }

    /**
     * Handles event where user clicks on editPhoto Button
     */
    @FXML
    public void editPhoto() {
    	
        int x = photoListView.getSelectionModel().getSelectedIndex();
    	SceneChange.ins.changingPhoto = photoViewList.remove(x);
    	SceneChange.ins.tempPhoto = SceneChange.ins.changingPhoto;

    	SceneChange.sceneChanger(this, editPhotoButton, "editPhotoScene.fxml");
    }

    /**
     * Handles event where user clicks on the deletePhoto button 
     */
    @FXML
   public void deletePhoto() {
			int x = photoListView.getSelectionModel().getSelectedIndex();
			photoViewList.remove(x);
			
            initialize();
    }

    /**
     * Handles event where user clicks on the movePhotoButton
     */
    @FXML
    public void movePhoto() {
        
        SceneChange.ins.changingPhoto = photoListView.getSelectionModel().getSelectedItem();
        SceneChange.sceneChanger(this, movePhotoButton, "movePhotoScene.fxml");
    }

    /**
     * Handles event where the user clicks on the copyPhotoButton
     */
    @FXML
    public void copyPhoto() {
        SceneChange.ins.changingPhoto = photoListView.getSelectionModel().getSelectedItem();
        SceneChange.sceneChanger(this, copyPhotoButton, "copyPhotoScene.fxml");
    }

    /**
     * Handles event where user clicks on slideShowViewButton
     */
    @FXML
    public void slideShowView() {
        SceneChange.ins.slideShowList = SceneChange.ins.currAlbum.photosInAlbum;
        SceneChange.ins.slide = photoListView.getSelectionModel().getSelectedIndex();

        SceneChange.sceneChanger(this, slideShowViewButton, "slideShowViewScene.fxml");
    }

}
