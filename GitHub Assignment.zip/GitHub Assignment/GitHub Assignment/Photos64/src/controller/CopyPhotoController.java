package controller;

import model.Album;
import model.SceneChange;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import java.util.ArrayList;

/**
 * Controller class for when user is in the copyPhotoScene
 * @author Usmaan Ilyas and Mazin Hamamou
 */
public class CopyPhotoController {
    
    @FXML
    private Button goBackButton;

    @FXML
    private ListView<Album> albumsListView;

    @FXML
    private Button confirmButton;

    /**
     * Observable list that is used to display all of the users available photo albums
     */
    ObservableList<Album> albumsOList = FXCollections.observableList(new ArrayList<Album>(SceneChange.ins.currUser.albums));

    /**
     * Handles event where user presses the goBackButton
     */
    @FXML
    public void goBack() {
        SceneChange.ins.changingPhoto = null;
        SceneChange.sceneChanger(this, goBackButton, "albumView.fxml");
    }

    /**
     * initializes the ListView with albums from this user
     */
    public void initialize() {
        albumsOList.remove(SceneChange.ins.currAlbum);
        albumsListView.setItems(albumsOList);

        albumsListView.getSelectionModel().select(0);
    }

    /**
     * Handles event where user clicks on confirmButton
     */
    @FXML
    public void confirm() {
        Album dest = albumsListView.getSelectionModel().getSelectedItem();

        dest.photosInAlbum.add(SceneChange.ins.changingPhoto.copyToAlbum(dest));
        
        SceneChange.ins.changingPhoto = null;
    	SceneChange.sceneChanger(this, confirmButton, "albumView.fxml");
    }

}
