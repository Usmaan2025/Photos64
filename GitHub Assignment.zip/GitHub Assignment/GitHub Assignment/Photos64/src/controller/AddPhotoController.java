package controller;


import model.SceneChange;
import model.Photo;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Controller class to deal with scene for when User wants to add new Photo to an album
 * @author Usmaan Ilyas and Mazin Hamamou
 */
public class AddPhotoController {

    /**
     * file to hold image this user is adding
     */
    private File image;
    
    @FXML 
    private Button goBackButton; //handled

    @FXML 
    private TextField captionTextField;

    @FXML 
    private ChoiceBox<String> tagNamesChoiceBox;

    @FXML 
    private TextField tagValueTextField;

    @FXML 
    private Button addTagButton; //handled

    @FXML 
    private Button newTagButton; //handled

    @FXML 
    private Button deleteTagButton; //handled

    @FXML 
    private ListView<String> tagsListView;

    @FXML 
    private Button chooseFileButton; //handled

    @FXML 
    private Label fileNameLabel;

    @FXML 
    private Button confirmButton; //handled

    /**
     * Observable List to hold and display preset tag types
     */
    ObservableList<String> presetTagNamesOList = FXCollections.observableList(SceneChange.ins.currUser.presetTags);

    /**
     * List of Strings for this session
     */
    private List<String> tags = new ArrayList<String>();

     /**
     * Observable List to hold and display all tags that have been created for this user
     */
    ObservableList<String> tagsOList = FXCollections.observableList(tags);

    /**
     * Initializes all lists and ListViews with correct and corresponding values.
     */
    public void initialize() {
    	tagNamesChoiceBox.setItems(presetTagNamesOList);
    	tagNamesChoiceBox.getSelectionModel().select(0);
    	
    	tagsListView.setItems(tagsOList);
    	tagsListView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
    	
    	
        if(SceneChange.ins.tempPhoto != null) {
    		
            Photo temp = SceneChange.ins.tempPhoto;
    		captionTextField.setText(temp.caption);
    		tagsOList.addAll(temp.listOfTags);
    		
            image = temp.fileOfPhoto;
    		if(image != null) {
    			fileNameLabel.setText(image.getAbsolutePath());
    		}
    		
            SceneChange.ins.tempPhoto = null;
    		
    		if(!tagsOList.isEmpty()) {
    			deleteTagButton.setDisable(false);
    		}
    	}
    }

    /**
     * Handles event where user wants to go back without editing the photo
     */
    @FXML
    public void goBack() {
    	SceneChange.sceneChanger(this, goBackButton, "albumView.fxml");
    }

    /**
     * Handles the event where the user adds a tag to the photo
     */
    @FXML
    public void addTag() {
    	String tagVal = tagValueTextField.getText();

    	tagValueTextField.setText("");
    	
        if(tagVal.equals("")) {
    		return;
    	}

    	
    	String pair = tagNamesChoiceBox.getSelectionModel().getSelectedItem() + "=" + tagVal;
    	if(!tagsOList.contains(pair)) {
	    	tagsOList.add(pair);
	    	tagsListView.getSelectionModel().select(0);
	    	deleteTagButton.setDisable(false);
    	}

    }

    /**
     * Handles event where user clicks on new tag button 
     */
    @FXML
    public void makeNewTag() {
    	SceneChange.ins.tempPhoto = Photo.refPhoto(image, captionTextField.getText(), tags);
    	SceneChange.sceneChanger(this, newTagButton, "newTagScene.fxml");
    }

    /**
     * Handles event where user clicks on deleteTagButton
     */
    @FXML
    public void deleteTag() {

    		tagsOList.remove(tagsListView.getSelectionModel().getSelectedIndex());
    		if(tagsOList.isEmpty()) {
    			deleteTagButton.setDisable(true);
    		}
            else {
    			tagsListView.getSelectionModel().select(0);
    			deleteTagButton.setDisable(false);
    		}
    }


   
    /**
     * Handles event where user clicks the choose file button
     */
    @FXML
    public void chooseFile() {
    	FileChooser f = new FileChooser();
    	f.getExtensionFilters().setAll(new ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg", "*.gif", "*.bmp"));
    	
        image = f.showOpenDialog(chooseFileButton.getScene().getWindow());

    	if(image != null) {
    		fileNameLabel.setText(image.getAbsolutePath());
    	}
        else {
    		fileNameLabel.setText("");
    	}
    }

    /**
     * Handles event where user clicks on confirm button
     * will save all changes to the photo
     */
    @FXML
    public void confirm() {
       
        if(image == null) {
    		SceneChange.alert(AlertType.ERROR, confirmButton, "You have not selected a file!"); return;
    	}
    	
    	Photo p = new Photo(SceneChange.ins.currAlbum, captionTextField.getText(), image, tags);
    	
        SceneChange.ins.currAlbum.photosInAlbum.add(p);
    	SceneChange.sceneChanger(this, confirmButton, "albumView.fxml");
    }









}
