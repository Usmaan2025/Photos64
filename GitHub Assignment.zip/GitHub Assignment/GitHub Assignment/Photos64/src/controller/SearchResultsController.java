package controller;

import model.Album;
import model.Photo;
import model.SceneChange;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.image.ImageView;

/**
 * Controller class for the search results scene
 * @author Usmaan Ilyas and Mazin Hamamou
 */
public class SearchResultsController {

    @FXML
    private Button goBackButton;

    @FXML
    private Button createAlbumButton;

    @FXML
    private ListView<Photo> searchResultsListView;

    private ObservableList<Photo> photoOList =  FXCollections.observableList(SceneChange.ins.results);

    /**
     * Handles event where the user presses the goBackButton
     */
    @FXML
    public void goBack() {
        SceneChange.sceneChanger(this, goBackButton, "searchScene.fxml");
    }

    /**
     * Method to initialize the ListView
     */
    public void initialize() {
        searchResultsListView.setItems(photoOList);

        searchResultsListView.setCellFactory(param -> new ListCell<Photo>() { public void updateItem(Photo p, boolean empty) {
    			super.updateItem(p, empty);
    			if(empty) {
    				setText(null);
    				setGraphic(null);
    			}
                else {
    				setText(p.caption + " ");
    				ImageView temp = new ImageView();
    				temp.setImage(p.thumbnail);
    				setGraphic(temp);
    			}
    		} });
            
            if(photoOList.isEmpty()) {
                createAlbumButton.setDisable(true);
            }
            else {
                createAlbumButton.setDisable(false);
                searchResultsListView.getSelectionModel().select(0);
            }

    }
   
    /**
     * Handles the event where the createAlbumButton is pressed
     */
    @FXML
     public void createSearchAlbum() {
        SceneChange.sceneChanger(this, createAlbumButton, "searchAlbumScene.fxml");
     }
}
