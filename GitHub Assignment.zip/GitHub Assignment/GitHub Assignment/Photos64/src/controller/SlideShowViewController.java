package controller;

import model.SceneChange;
import model.Album;
import model.Photo;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.image.ImageView;

/**
 * Controller class for the slideShowView Scene
 * @author Usmaan Ilyas and Mazin Hamamou
 */

public class SlideShowViewController {
    
    @FXML
    private ImageView photoSlide;

    @FXML
    private Button goBackButton;

    @FXML
    private Button nextPhotoButton;

    @FXML
    private Button previousPhotoButton;

    @FXML
    private TextArea photoDesc;

    /**
     * Photo pointer to keep track of the current photo slide
     */
    private Photo slidePhoto;

    /**
     * Initializes the ImageView of the photo to the correct photo slide and initializes the description to the corresponding description
     */
    public void initialize() {
    	
        slidePhoto = SceneChange.ins.slideShowList.get(SceneChange.ins.slide);
    	
        if(slidePhoto.fileOfPhoto.exists()) {
    		photoDesc.setText(slidePhoto.description());
    	}
        else {
    		photoDesc.setText("No Image File found \n" + slidePhoto.description());
    	}
    	photoSlide.setImage(slidePhoto.accSize);
    	
        if((SceneChange.ins.slide + 1) < SceneChange.ins.slideShowList.size()) {
    		
            nextPhotoButton.setDisable(false);
    	}
        else {
    		nextPhotoButton.setDisable(true);
    	}
    	if((SceneChange.ins.slide - 1) > -1) {
    		previousPhotoButton.setDisable(false);
    	}
        else {
    		previousPhotoButton.setDisable(true);
    	}
    }

    /**
     * Handles event where user clicks the goBackButton
     */
    public void goBack() {
        SceneChange.ins.slide = -1;
        SceneChange.ins.slideShowList = null;
        SceneChange.sceneChanger(this, goBackButton, "albumView.fxml");
    }

    /**
     * Handles the event where user clicks on the nextPhotoButton
     */
    @FXML
    public void nextPhoto() {
        SceneChange.ins.slide++;
        initialize();
    }

    /**
     * Handles event where the user clicks on the previousPhotoButton
     */
    @FXML
    public void previousPhoto() {
        SceneChange.ins.slide --;
        initialize();
    }

}
