package controller;


import javafx.fxml.FXML;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.Alert.AlertType;
import model.SceneChange;
import model.User;

/**
 * Controller class to deal with admin account
 * @author Usmaan Ilyas and Mazin Hamamou
 */
public class AdminController {
    
    @FXML
      private Button logOutButton;

    @FXML
     private Button addUserButton;

    @FXML
     private Button deleteUserButton;

    @FXML
     private ListView<User> listOfUsers;


    /**
     * Observable List used to show list of users
     */
    ObservableList<User> userListDisplay = FXCollections.observableList(SceneChange.ins.users);

    /**
     * Will initialize the list view with the contents of the observable list, userListDisplay
     */
    public void initialize() {
        listOfUsers.setItems(userListDisplay);
    	listOfUsers.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
    	
        if(SceneChange.ins.users.isEmpty()) {
    		deleteUserButton.setDisable(true);
    
        }else {
    		deleteUserButton.setDisable(false);
    		listOfUsers.getSelectionModel().select(0);
    	}
    }

    /**
     * Switches to addUser Scene after handling the event of the add user button being pressed
     */
    
    public void addUser() {
        SceneChange.sceneChanger(this, addUserButton, "addUserScene.fxml");
    }

    /**
     * Handles the event where someone wishes to delete selected user
     */
    
    public void deleteUser() {
        User u = listOfUsers.getSelectionModel().getSelectedItem();
        userListDisplay.remove(u);
        initialize();
    }

    public void logOut() {
    	SceneChange.ins.currUser = null;
    	try {
			SceneChange.writeToFile();
		} catch (Exception e1) {
			SceneChange.alert(AlertType.INFORMATION, logOutButton,
					"Something caused a file saving error.");
		}
    	SceneChange.sceneChanger(this, logOutButton, "logInScene.fxml");
    }






}
