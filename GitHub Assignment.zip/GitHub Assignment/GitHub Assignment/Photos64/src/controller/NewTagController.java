package controller;

import model.SceneChange;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;


/**
 * Controller class for the scene where a user wants to add a new tag type 
 * @author Usmaan Ilyas and Mazin Hamamou
 */
public class NewTagController {


    @FXML
    private TextField newTagTextField; //handled
    
    @FXML
    private Button goBackButton; //handled

    @FXML
    private Button enterButton; //handled

    /**
     * handles event where user clicks goBack button
     */
    @FXML
    public void goBack() {
        SceneChange.sceneChanger(this, goBackButton, "addPhotoScene.fxml");
    }

    /**
     * Handles event where user clicks the Go Back button
     */
    @FXML
    public void enter() {
    	String tagName = newTagTextField.getText().toLowerCase();
    	
        if(tagName.equals("") || SceneChange.ins.currUser.presetTags.contains(tagName)) {
    		SceneChange.sceneChanger(this, enterButton, "addPhotoScene.fxml");
    	}
        else {
    		SceneChange.ins.currUser.presetTags.add(tagName);
    		SceneChange.sceneChanger(this, enterButton, "addPhotoScene.fxml");
    	}
    }


}
