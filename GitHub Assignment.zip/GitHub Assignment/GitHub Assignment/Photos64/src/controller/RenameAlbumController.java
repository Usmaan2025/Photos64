package controller;

import model.Album;
import model.SceneChange;
import java.util.ArrayList;
import java.util.List;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
/**
 * Controller class for when user is renaming album
 * @author Usmaan Ilyas and Mazin Hamamou
 */
public class RenameAlbumController {
    
    @FXML
    private Button goBackButton;

    @FXML
    private Button enterButton;

    @FXML
    private TextField albumRenameTextField;


    /**
     * list of albums to compare to in case user enters a duplicate name as a prior album
     */
    private List<Album> albumNames = new ArrayList<Album>(SceneChange.ins.currUser.albums);

    /**
     * Initializing method to remove the current album from the list of albums to compare to
     */
    public void initialize() {
        albumNames.remove(SceneChange.ins.currAlbum);
    }

    /**
     * Handles the event where the user clicks on the goBackButton
     */
    @FXML
    public void goBack() {
        SceneChange.ins.currAlbum = null;
        SceneChange.sceneChanger(this, goBackButton, "albumListScene.fxml");
    }

    /**
     * Handles the event where user clicks on the enterButton and submits a name to rename their album to
     */
    @FXML
    public void enterName() {
        String reName = albumRenameTextField.getText();
    	
        if(reName.equals("")) {
    		SceneChange.alert(AlertType.WARNING, enterButton, "Invalid album name");
    	}
        
        else {
    		for(Album a : albumNames) {
    			if(a.name.equals(reName)) {
    				SceneChange.alert(AlertType.ERROR, enterButton, "You already have an album under this name!");
    				
                    return;
    			}
    		}
			
            SceneChange.ins.currAlbum.name = reName;
			SceneChange.ins.currAlbum = null;
			SceneChange.sceneChanger(this, enterButton, "albumListScene.fxml");
    	}
    }
}
