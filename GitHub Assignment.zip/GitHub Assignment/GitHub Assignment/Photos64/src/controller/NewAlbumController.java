package controller;
import model.SceneChange;
import model.Album;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;

/**
 * Controller class for the New Album Scene
 * @author Usmaan Ilyas and Mazin Hamamou
 */
public class NewAlbumController {
    
    @FXML
    private Button enterButton;

    @FXML
    private Button goBackButton;

    @FXML
    private TextField newAlbumTextField;

    /**
     * Handles event where the user presses the enter button after either entering a valid or invalid album name
     */
    @FXML
    public void enterNewAlbum() {
        String albumName = newAlbumTextField.getText();
        Album a = SceneChange.ins.currUser.checkAlbum(albumName);

        if(albumName.equals("")) {
            SceneChange.alert(AlertType.ERROR, enterButton, "Invalid album name");
        }
        else if(a != null) {
            SceneChange.alert(AlertType.ERROR, enterButton, "Cannot create duplicate album names under the same user!");
        }
        else {
            SceneChange.ins.currUser.albums.add(new Album(albumName));
    			SceneChange.sceneChanger(this, enterButton, "albumListScene.fxml");
        }
    }

    /**
     * Handles the event where the user clicks the goBack button prior to entering the new album name
     */
    @FXML
    public void goBack() {
        SceneChange.sceneChanger(this, goBackButton, "albumListScene.fxml");
    }
}
