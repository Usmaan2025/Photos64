package controller;

import javafx.fxml.FXML;
import model.SceneChange;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import model.User;


/**
 * Controller class for the Add user Scene
 */
public class AddUserController {
    
    @FXML
    private Button add;

    @FXML
    private TextField userNameEntered;

    @FXML
    private Button goBack;

    /**
     * Handles the event where the user confirms to add user
     */
    @FXML
    public void confirmAddUser() {
        String name = userNameEntered.getText().strip();
    	if(name.equals("")) {
    		SceneChange.alert(AlertType.WARNING, add,
    				"Invalid user name!");
    	}
        else if(name.equals("admin")) {
    		SceneChange.alert(AlertType.ERROR, add, "Username is already taken");
    	}
        else {
    		User u = SceneChange.ins.getUser(name);
    		if(u != null) {
    			SceneChange.alert(AlertType.ERROR, add, "Username is already taken");
    		}else {
    			SceneChange.ins.users.add(new User(name));
    			SceneChange.sceneChanger(this, add, "admin.fxml");
    		}
    	}
    }

    /**
     * Handles the event where the user presses the go back button
     */
    @FXML
    public void goBackEvent() {
        SceneChange.sceneChanger(this, goBack, "admin.fxml");
    }

}
