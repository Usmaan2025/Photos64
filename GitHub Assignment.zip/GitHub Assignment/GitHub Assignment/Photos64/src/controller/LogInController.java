package controller;
import java.io.IOException;

import javafx.scene.control.Alert.AlertType;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import model.SceneChange;
import model.User;

/**
 * Controller class to deal with log in 
 * @author Usmaan Ilyas and Mazin Hamamou
 */
public class LogInController {
    

    @FXML
    private Button logInButton;

    @FXML
    private TextField userNameTextField;


    
    public void logIn(ActionEvent event) throws IOException {
        String user = userNameTextField.getText();
        
        if(user.equals("admin")) {
            SceneChange.sceneChanger(this, logInButton, "admin.fxml");
        }
        else if(user.equals("") || SceneChange.ins.getUser(user) == null)  {
            SceneChange.alert(AlertType.WARNING, logInButton, "Invalid input!");
        }
        else {
            User use = SceneChange.ins.getUser(user);
            SceneChange.ins.currUser = use;
            SceneChange.sceneChanger(this, logInButton, "albumListScene.fxml");
        }

    }
}
