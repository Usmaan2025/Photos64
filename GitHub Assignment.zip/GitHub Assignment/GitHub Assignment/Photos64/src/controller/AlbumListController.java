package controller;

import model.SceneChange;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.Alert.AlertType;
import model.Album;
import javafx.beans.property.SimpleStringProperty;

/**
 * Controller class for when user logs in successfully to account other than admin
 * @author Usmaan Ilyas and Mazin Hamamou
 */
public class AlbumListController {

    /**
     * An ObservableList to show the users albums in the TableView
     */
    ObservableList<Album> albumList = FXCollections.observableList(SceneChange.ins.currUser.albums);

    @FXML Button openAlbumButton; //handled
    
    @FXML Button logOutButton; //handled

    @FXML Button searchButton; //handled?

    @FXML Button newAlbumButton; //handled

    @FXML Button deleteAlbumButton; //handled

    @FXML Button renameAlbumButton; //handled

    @FXML TableView<Album> albumTable;

    
    
    /**
     * Initializes TableView with all different values that are already stored in the user
     * SuppressWarnings tag is needed to get around a warning for the users as a result of lambda expressions
     */
	@SuppressWarnings("unchecked")
	public void initialize() {
		for(Album a : SceneChange.ins.currUser.albums) {
    		a.updateFields();
    	}
		albumList.sort((a1, a2) -> a1.name.compareTo(a2.name));
		
    	albumTable.setItems(albumList);
    	var nameCol = (TableColumn<Album, String>) albumTable.getColumns().get(0);
    	var numberCol = (TableColumn<Album, String>) albumTable.getColumns().get(1);
    	var earliestPhotoCol = (TableColumn<Album, String>) albumTable.getColumns().get(2);
    	var latestPhotoCol = (TableColumn<Album, String>) albumTable.getColumns().get(3);
    	
    	
    	nameCol.setCellValueFactory(album -> new SimpleStringProperty(album.getValue().name));
    	numberCol.setCellValueFactory(album -> new SimpleStringProperty(album.getValue().amountOfPhotos + ""));
    	earliestPhotoCol.setCellValueFactory(album -> new SimpleStringProperty(album.getValue().earliestDate));
    	latestPhotoCol.setCellValueFactory(album -> new SimpleStringProperty(album.getValue().latestDate));
    	
    	if(SceneChange.ins.currUser.albums.isEmpty()) {
    		deleteAlbumButton.setDisable(true);
    		renameAlbumButton.setDisable(true);
    		openAlbumButton.setDisable(true);
    		searchButton.setDisable(true);
    	}else {
    		deleteAlbumButton.setDisable(false);
    		renameAlbumButton.setDisable(false);
    		openAlbumButton.setDisable(false);
    		searchButton.setDisable(true);
    		for(Album a : SceneChange.ins.currUser.albums) {
    			if(!a.photosInAlbum.isEmpty()) {
    				searchButton.setDisable(false);
    				break;
    			}
    		}
    		albumTable.getSelectionModel().select(0);
    	}


}

    /**
     * Method to handle the event of user clicking the new album button; will take them to a screen where they
     * can enter the name of their new album.
     */
    @FXML
    public void newAlbum() {
        SceneChange.sceneChanger(this, newAlbumButton, "newAlbumScene.fxml");
    }

    /**
     * Method to handle the event of user clicking the open album button, will take them to the openAlbumScene
     */
    @FXML
    public void openAlbum() {
        SceneChange.ins.currAlbum = albumTable.getSelectionModel().getSelectedItem();

        SceneChange.sceneChanger(this, openAlbumButton, "albumView.fxml");
    }

	/**
	 * Method to handle the event of a usser clicking the logOut button while on the album list screen
	 * saves information from this session 
	 */
	@FXML
	public void logOut() {
		SceneChange.ins.currUser = null;

		try {
			SceneChange.writeToFile();
		} catch(Exception e) {}

		SceneChange.sceneChanger(this, logOutButton, "loginScene.fxml");
	}

	/**
	 * Handles event where user presses the deleteAlbumButton
	 */
	@FXML
	public void deleteAlbum() {
		albumList.remove(albumTable.getSelectionModel().getSelectedIndex());
		initialize();
	}

	/**
	 * Handles event where user presses the renameAlbumButton and renames their album
	 */
	@FXML
	public void renameAlbum() {
		SceneChange.ins.currAlbum = albumTable.getSelectionModel().getSelectedItem();
		SceneChange.sceneChanger(this, renameAlbumButton, "renameAlbumScene.fxml");
	}

	/**
	 * Handles the event where the user presses the searchBUtton announcement
	 */
	@FXML
	public void search() {
		SceneChange.sceneChanger(this, searchButton, "searchScene.fxml");
	}







}
