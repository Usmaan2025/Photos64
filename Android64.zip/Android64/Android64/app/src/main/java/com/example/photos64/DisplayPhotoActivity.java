package com.example.photos64;

import androidx.appcompat.app.AppCompatActivity;


import android.app.AlertDialog;
import android.content.DialogInterface;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.content.Intent;

import com.google.android.material.textfield.TextInputLayout;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class DisplayPhotoActivity extends AppCompatActivity {

    private TextView displayTextView;

    private TextInputLayout tagValue;

    private RadioGroup radGroup;

    private Button backButton;
    private Button prevButton;
    private Button nextButton;
    private Button delTagButton;
    private Button addTagButton;

    private ImageView dispImageView;

    private ListView tagListView;

    private EditText tagEditText;

    private RadioButton personRadButton;
    private RadioButton locRadButton;

    private ArrayList<Album> albumsList;

    private Album currentAlbum;

    private Photo currentPhoto;

    private Tag currentTag;
    private int albIndex;
    private int photoIndex;

    String path;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_photo);

        path = this.getApplicationInfo().dataDir + "/data.dat";

        Intent intent = getIntent();

        albumsList = (ArrayList<Album>) intent.getSerializableExtra("albumsList");
        currentAlbum = (Album) intent.getSerializableExtra("currentAlbum");
        albIndex = intent.getIntExtra("albIndex", 0);

        currentPhoto = (Photo) intent.getSerializableExtra("currentPhoto");

        photoIndex = intent.getIntExtra("position", 0);

         radGroup = (RadioGroup) findViewById(R.id.radGroup);
        personRadButton = (RadioButton) findViewById(R.id.pTypeRad);
        locRadButton = (RadioButton) findViewById(R.id.lTypeRad);

        tagValue = findViewById(R.id.tagValue);
        tagListView = (ListView) findViewById(R.id.tagListView);

        displayTextView = findViewById(R.id.displayTextView);
        displayTextView.setText((currentAlbum.getAlbumName() + " photos"));

        dispImageView = findViewById(R.id.dispImageView);
        dispImageView.setImageURI(Uri.parse(currentPhoto.getPath()));

        if(!currentPhoto.getTagList().isEmpty()) {

            tagsUpdate(currentPhoto);

            tagListView.setItemChecked(0, true);
            currentTag = currentPhoto.getTagList().get(0);
            if(currentTag.getType().equals("person"))

                radGroup.check(R.id.pTypeRad);
            else
                radGroup.check(R.id.lTypeRad);

            tagValue.setHint(currentTag
                    .getValue());
        } else {
            tagListView.setAdapter(null);
            radGroup.check(R.id.pTypeRad);
        }

        tagListView.setOnItemClickListener((parent, view, position, id) -> {
            tagListView.setItemChecked(position,true);
            currentTag = currentPhoto.getTagList().get(position);

            if(currentTag.getType().equals("person"))
                radGroup.check(R.id.pTypeRad);
            else
                radGroup.check(R.id.lTypeRad);

            tagValue.setHint(currentTag.getValue());
        });
    }

    public void deleteTag(View view){
        AlertDialog.Builder b = new AlertDialog.Builder(this);

        if(currentPhoto.getTagList().isEmpty()){
            b.setTitle("ERROR");
            b.setMessage("You have no tags for this photo");
            b.setPositiveButton("Close", null);
            b.show(); return;
        }

        b.setTitle("Delete Tag");
        b.setMessage("Delete tag?");
        b.setPositiveButton("Yes",
                (dialog, which) -> {
                    albumsList.get(albIndex).getPhotosInAlbum().get(photoIndex).removeTag(currentTag.getType(), currentTag.getValue());

                    currentPhoto = albumsList.get(albIndex).getPhotosInAlbum().get(photoIndex);

                    saveUserData(albumsList);
                    tagsUpdate(currentPhoto);

                    if(!currentPhoto.getTagList().isEmpty()) {
                        tagListView.setItemChecked(0, true);
                        currentTag = currentPhoto.getTagList().get(0);

                        if(currentTag.getType().equals("person"))
                            radGroup.check(R.id.pTypeRad);
                        else
                            radGroup.check(R.id.lTypeRad);

                        tagValue.setHint(currentTag.getValue());
                    }
                    else
                        radGroup.check(R.id.pTypeRad);
                });
        b.setNegativeButton("No",
                (dialog, which) -> dialog.cancel());

        b.show();

        return;

    }

    public void addTag(View view){
        AlertDialog.Builder b = new AlertDialog.Builder(this);

        tagValue = findViewById(R.id.tagValue);

        if(tagValue.getEditText().getText().toString().isEmpty()){
            b.setTitle("ERROR!");
            b.setMessage("Please enter a value");
            b.setPositiveButton("Close", null);
            b.show();
            return;
        }

        String selected = "person";
        boolean multi = true;


        if (personRadButton.isChecked()) {
            selected = "person";
            multi = true;
        }
        else if (locRadButton.isChecked()) {
            multi = false;
            selected = "location";
        }

        Tag newTag = new Tag(selected, tagValue.getEditText().getText().toString(), multi);

        for(Tag t: currentPhoto.getTagList()){
            if(t.equals(newTag)){
                b.setTitle("ERROR");
                b.setMessage("Tag already exists. ");
                b.setPositiveButton("Close", null);
                b.show(); return;
            }
            else if(t.getType().equals("location") && newTag.getType().equals("location")){
                b.setTitle("ERROR");
                b.setMessage("Please enter only one value for location");
                b.setPositiveButton("Close", null);
                b.show(); return;
            }
        }

        b.setTitle("New Tag");
        b.setMessage("Add new tag " + newTag.toString() + " to "+ currentPhoto.getName()+"?");

        b.setPositiveButton("Yes",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        albumsList.get(albIndex).getPhotosInAlbum().get(photoIndex).addNewTag(newTag);

                        currentPhoto = albumsList.get(albIndex).getPhotosInAlbum().get(photoIndex);
                        currentTag = newTag;

                        saveUserData(albumsList);
                        tagsUpdate(currentPhoto);

                        tagListView.setItemChecked(currentPhoto.getTagList().size()-1, true);
                    }
                });
        b.setNegativeButton("No",
                (dialog, which) -> dialog.cancel());
        b.show();

        radGroup.clearCheck();

        radGroup.check(R.id.pTypeRad);
        tagValue.getEditText().setText("");
        return;
    }

    public void saveUserData(ArrayList<Album> a) {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(path);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);

            objectOutputStream.writeObject(a);

            objectOutputStream.close();
            fileOutputStream.close();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public void prevPhoto(View view){
        if(photoIndex-1 <0){
            photoIndex= currentAlbum.getPhotosInAlbum().size()-1;


            dispImageView.setImageURI(Uri.parse(currentAlbum.getPhotosInAlbum().get(photoIndex).getPath()));
        }
        else{
            photoIndex--;
            dispImageView.setImageURI(Uri.parse(currentAlbum.getPhotosInAlbum().get(photoIndex).getPath()));
        }

        currentPhoto = albumsList.get(albIndex).getPhotosInAlbum().get(photoIndex);

        tagsUpdate(currentPhoto);

        if(!currentPhoto.getTagList().isEmpty()) {
            tagListView.setItemChecked(0, true);
            currentTag = currentPhoto.getTagList().get(0);

            if(currentTag.getType().equals("person"))
                radGroup.check(R.id.pTypeRad);

            else
                radGroup.check(R.id.lTypeRad);

            tagValue.setHint(currentTag.getValue());
        }
        else radGroup.check(R.id.pTypeRad);
    }

    public void nextPhoto(View view){
        if(photoIndex +1 >= currentAlbum.getPhotosInAlbum().size()){
            photoIndex=0;

            dispImageView.setImageURI(Uri.parse(currentAlbum.getPhotosInAlbum().get(photoIndex).getPath()));
        } else{
            photoIndex++;
            dispImageView.setImageURI(Uri.parse(currentAlbum.getPhotosInAlbum().get(photoIndex).getPath()));
        }
        currentPhoto = albumsList.get(albIndex).getPhotosInAlbum().get(photoIndex);

        tagsUpdate(currentPhoto);
        if(!currentPhoto.getTagList().isEmpty()) {
            tagListView.setItemChecked(0, true);

            currentTag = currentPhoto.getTagList().get(0);

            if(currentTag.getType().equals("person"))

                radGroup.check(R.id.pTypeRad);
            else
                radGroup.check(R.id.lTypeRad);

            tagValue.setHint(currentTag.getValue());
        }
        else
            radGroup.check(R.id.pTypeRad);
    }

    public void backButton(View view) {
        Intent intent = new Intent(this, OpenAlbumActivity.class);

        intent.putExtra("albumsList", albumsList);
        intent.putExtra("albIndex", albIndex);
        intent.putExtra("currentAlbum", currentAlbum
        );
        startActivity(intent);
    }

    public void tagsUpdate(Photo p) {
        if (p == null || p.getTagList().size() == 0) {
            tagListView.setAdapter(null);return;
        }
        ArrayList<String> tagNames = new ArrayList<>();

        for (Tag t: p.getTagList())
            tagNames.add(t.toString());

        ArrayAdapter<String> adpt = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, tagNames);

        adpt.setNotifyOnChange(true);

        tagListView = findViewById(R.id.tagListView);
        tagListView.setAdapter(adpt);
        tagListView.refreshDrawableState();
    }
}