package com.example.photos64;
import androidx.annotation.Nullable;

import java.io.Serializable;

public class Tag implements Serializable{
    private static final long serialVersionUID = 42L;



    private String type;
    private String value;
    private boolean multiple;
    public Tag(String name, String value, boolean multi) {
        this.type = name.toLowerCase();
        this.value = value;
        this.multiple = multi;
    }

    public String getType() {
        return type;
    }
    public String getValue() {
        return value;
    }
    public boolean getMultiple() {
        return multiple;
    }

    public String toString() {
        String tag = type + ": " + value;
        return tag;
    }


    @Override
    public boolean equals( Object obj) {
        if(obj ==null || !(obj instanceof Tag)) return false;

    Tag thisTag = (Tag) obj;
        return thisTag.getType().toLowerCase().equals(type.toLowerCase()) &&
                thisTag.getValue().toLowerCase().equals(value.toLowerCase());
    }
}
