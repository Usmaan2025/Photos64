package com.example.photos64;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import android.widget.RadioButton;

import com.google.android.material.textfield.TextInputLayout;

import java.util.ArrayList;

public class SearchActivity extends AppCompatActivity {


    private GridView searchPhotoGridView;
    private Button searchButton;
    private Button resetButton;
    private Button backButton;

    private RadioButton andRadButton;
    private RadioButton orRadButton;

    private TextInputLayout personTagLayout;
    private TextInputLayout locationTagLayout;

    private ArrayList<Album> albumsList;
    private Album currAlbum;

    private int albIndex;

    String path;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.search_page);

        path = this.getApplicationInfo().dataDir + "/data.dat";

        searchButton = (Button) findViewById(R.id.searchPageButton);
        resetButton = (Button) findViewById(R.id.resetButton);
        backButton = (Button) findViewById(R.id.backButton);

        andRadButton = (RadioButton) findViewById(R.id.andRadButton);
        orRadButton = (RadioButton) findViewById(R.id.orRadButton);

        searchPhotoGridView = (GridView) findViewById(R.id.searchPhotoImageView);

        personTagLayout = findViewById(R.id.personTagLayout);
        locationTagLayout = findViewById(R.id.locationTagLayout);

        Intent i = getIntent();
        albumsList = (ArrayList<Album>) i.getSerializableExtra("albumsList");
        if (albumsList == null || albumsList.isEmpty()) return;

        albIndex = i.getIntExtra("albIndex", 0);
        currAlbum = albumsList.get(albIndex);


    }
    public ArrayList<Photo> checkTag(String person, String location) {
        ArrayList<Photo> checkList = new ArrayList<>();

        for (Album a: albumsList) {
            Album thisAlbum = a;

            if (andRadButton.isChecked()) {
                Tag tempPerson = new Tag("person", person, false);
                Tag tempLoc = new Tag("location", location, false);

                for (Photo p: thisAlbum.getPhotosInAlbum()) {
                    boolean pFound = false;
                    boolean lFound = false;

                    Photo thisPhoto = p;

                    for (Tag t: thisPhoto.getTagList()) {
                        Tag currTagTemp = t;
                        if (currTagTemp.getType().toLowerCase().equals("person") && currTagTemp.getValue().length() > person.length()) {
                            currTagTemp = new Tag("person", currTagTemp.getValue().substring(0, person.length()), false);}
                        else if (currTagTemp.getType().toLowerCase().equals("location") && currTagTemp.getValue().length() > location.length()) {
                            currTagTemp = new Tag("location", currTagTemp.getValue().substring(0, location.length()), false);
                        }

                        if (currTagTemp.equals(tempPerson))
                            pFound = true;
                        if (currTagTemp.equals(tempLoc))
                            lFound = true;

                        if ((pFound && lFound) && !inList(checkList, thisPhoto)) {
                            checkList.add(thisPhoto);
                            break;
                        }
                    }
                }
            }
            else if (orRadButton.isChecked()) {
                Tag tempPerson = new Tag("person", person, false);
                Tag tempLoc = new Tag("location", location, false);

                for (Photo x: thisAlbum.getPhotosInAlbum()) {
                    Photo thisPhoto = x;

                    for (Tag t: thisPhoto.getTagList()) {
                        Tag tempTag = t;
                        if (tempTag.getType().toLowerCase().equals("person") && tempTag.getValue().length() > person.length()) {
                            tempTag = new Tag("person", tempTag.getValue().substring(0, person.length()), false);
                        }
                        else if (tempTag.getType().toLowerCase().equals("location") && tempTag.getValue().length() > location.length()) {
                            tempTag = new Tag("location", tempTag.getValue().substring(0, location.length()), false);
                        }

                        if ((tempTag.equals(tempPerson) || tempTag.equals(tempLoc)) && !inList(checkList, thisPhoto)) {
                            checkList.add(thisPhoto);
                            break;
                        }
                    }
                }
            }
            else {
                Tag temp;
                if (person.equals(""))
                    temp = new Tag("location", location, false);
                else
                    temp = new Tag("person", person, false);

                for (Photo p: thisAlbum.getPhotosInAlbum()) {
                    Photo thisPhoto = p;

                    for (Tag t: p.getTagList()) {
                        Tag tempTag = t;
                        if (tempTag.getType().toLowerCase().equals("person") && tempTag.getValue().length() > person.length()) {
                            tempTag = new Tag("person", tempTag.getValue().substring(0, person.length()), false);
                        }
                        else if (tempTag.getType().toLowerCase().equals("location") && tempTag.getValue().length() > location.length()) {
                            tempTag = new Tag("location", tempTag.getValue().substring(0, location.length()), false);
                        }

                        if (tempTag.equals(temp) && !inList(checkList, thisPhoto)) {
                            checkList.add(thisPhoto);
                            break;
                        }
                    }
                }
            }
        }

        return checkList;
    }

    public boolean inList(ArrayList<Photo> list, Photo p) {
        for (Photo x: list) {
            if (x.getPath().equals(p.getPath())) return true;
        }

        return false;
    }

    public void search(View v) {
        ArrayList<Photo> checkList = new ArrayList<>();

        personTagLayout.setError(null);
        locationTagLayout.setError(null);

        String person;
        String location;
        try {
            person = personTagLayout.getEditText().getText().toString().trim();
            location = locationTagLayout.getEditText().getText().toString().trim();
        }
        catch (NullPointerException e) {
            person = "";
            location = "";
        }


        if (andRadButton.isChecked() || orRadButton.isChecked()) {
            if (person.equals("")) {
                personTagLayout.setError("Please enter a value in the person field"); return;
            }
            if (location.equals("")) {
                locationTagLayout.setError("Please enter a value in the location field");return;
            }
            if (!person.equals("") && !location.equals("")) {
                personTagLayout.setError(null);
                locationTagLayout.setError(null);
                searchPhotoGridView.removeAllViewsInLayout();
                checkList = checkTag(person, location);
            }
        }
        else {
            if (person.equals("") && location.equals("")) {
                personTagLayout.setError("Please enter a value in one of the fields");
                locationTagLayout.setError("Please enter a value in one of the fields");
                return;
            }
            else if (!person.isEmpty() && !location.isEmpty()) {
                personTagLayout.setError("Please enter a value in only one field!");
                locationTagLayout.setError("Choose 'And' or 'Or'!");
                return;
            }
            else {
                personTagLayout.setError(null);
                locationTagLayout.setError(null);
                searchPhotoGridView.removeAllViewsInLayout();
                checkList = checkTag(person, location);
            }
        }

        if (checkList.isEmpty())
            searchPhotoGridView.setAdapter(null);
        else {
            PhotoAdapter photoAdaptor = new PhotoAdapter(this, R.layout.photo_adapter_layout , checkList);
            searchPhotoGridView.setAdapter(photoAdaptor);
        }
    }
    public void reset(View view) {
        personTagLayout.getEditText().setText("");
        locationTagLayout.getEditText().setText("");
        personTagLayout.setError(null);
        locationTagLayout.setError(null);
        andRadButton.setChecked(false);
        orRadButton.setChecked(false);
        searchPhotoGridView.removeAllViewsInLayout();
    }

    public void back(View v) {
        Intent i = new Intent(this, Photos.class);

        i.putExtra("albumsList", albumsList);
        i.putExtra("currAlbum", currAlbum);
        i.putExtra("albIndex", albIndex);
        startActivity(i);
    }

}