package com.example.photos64;
import java.util.List;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;

import android.app.Activity;
import android.content.Context;
import android.net.Uri;

public class PhotoAdapter extends ArrayAdapter<Photo> {

    private List itemsInList;

    private Context ctx;

    public PhotoAdapter(Context context, int id, List<Photo> list) {
        super(context, id, list);
        this.ctx = context;
        this.itemsInList = list;
    }


    @Override
    public View getView(int position,  View convertView,  ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) ctx.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);

        if (convertView == null) convertView = inflater.inflate(R.layout.photo_adapter_layout, null);


        ImageView enter = (ImageView) convertView.findViewById(R.id.displayImageView);

        Photo p = (Photo) itemsInList.get(position);
        enter.setImageURI(Uri.parse(p.getPath()));
        return convertView;

    }
}
