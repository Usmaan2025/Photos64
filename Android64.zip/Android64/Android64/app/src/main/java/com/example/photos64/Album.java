package com.example.photos64;
import androidx.annotation.Nullable;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Album object
 */
public class Album implements Serializable{
    private static final long serialVersionUID = 42L;



    //name of the album
    public String albumName;

    //List of photos(actual album itself)
   public  List<Photo> photosInAlbum;

    //number of photos in the album
    public int numOfPhotos;

    //constructor
    public Album(String name) {this.albumName = name; photosInAlbum = new ArrayList<>();}

    //update size when necessary
    public void updateFields() {
        numOfPhotos = photosInAlbum.size();
    }

    public String toString() {
        return albumName;
    }

    public void addPhoto(Photo p) {
    //may need to handle case where user adds two of the same photo
        photosInAlbum.add(p);
    }
    public Photo findPhoto(Photo find) {
        for(Photo p: photosInAlbum) {
            if(find.equals(p)) return p;
        }
        return null;
    }


    public void removePhoto(Photo p) {
        if(findPhoto(p) != null) photosInAlbum.remove(findPhoto(p));
    }

    public String getAlbumName() {
        return albumName;
    }

    public void setAlbumName(String n) {
        this.albumName = n;

    }
    public void setPhotosInAlbum(List<Photo> diffAlbum) {this.photosInAlbum = diffAlbum;}

    public List<Photo> getPhotosInAlbum() {
        return photosInAlbum;
    }

    @Override
    public int hashCode() {
        return Objects.hash(albumName);
    }

    @Override
    public boolean equals( Object obj) {
        if(obj==null || !(obj instanceof Album)) return false;
        Album a =(Album) obj;
        return a.getAlbumName().toLowerCase().equals(albumName.toLowerCase());
    }
}
