package com.example.photos64;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import androidx.appcompat.app.AlertDialog;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;

import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;


public class Photos extends AppCompatActivity {
    String currentAlbumTxt;
    private ListView albumListView;
    private GridView photoGridView;
    private TextView albumTextView;

    private Album currentAlbum;
    private Photo currPhoto;

    public String path;
    private int albIndex;

    private ArrayList<Album> albumsList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
//        UserData.readFromFile(); causing an issue for some reason
        super.onCreate(savedInstanceState);
        setContentView(R.layout.photos);

        path = this.getApplicationInfo().dataDir + "/data.dat";
        currentAlbumTxt = this.getApplicationInfo().dataDir + "/h.txt"; //can lead to No line found error
        File baseFile = new File(path);
        File currAlbumFile = new File(currentAlbumTxt);

        //if respective files do not exist
        if (!baseFile.exists()) {
            try { baseFile.createNewFile();
            } catch (IOException e) { e.printStackTrace();}
        }
        else {
            try {
                FileInputStream fileInputStream = new FileInputStream(path);
                ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
                albumsList = (ArrayList<Album>) objectInputStream.readObject();
                objectInputStream.close();
                fileInputStream.close();
            } catch (Exception exception) {
                exception.printStackTrace();
            }
        }

        //if album file does not exist
        if (!currAlbumFile.exists()) {
            try {
                currAlbumFile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        else {
            try {
                albIndex = readPos(currAlbumFile);
            } catch (IOException e) { e.printStackTrace();}
        }

        Toolbar tb = (Toolbar) findViewById(R.id.mainToolBar);
        setSupportActionBar(tb);

        FloatingActionButton searchButton = (FloatingActionButton) findViewById(R.id.searchButton);
        albumListView = (ListView) findViewById(R.id.albumListView);
        photoGridView = (GridView) findViewById(R.id.photoGridView);
        albumTextView = (TextView) findViewById(R.id.albumTextView);
        albumTextView.setText(("Album"));


        Intent intent = getIntent();
        if (intent.getSerializableExtra("albumsList") != null)
            albumsList = (ArrayList<Album>) intent.getSerializableExtra("albumsList");

        if (albumsList != null && !albumsList.isEmpty()) {
            if (intent.getIntExtra("albIndex", -1) != -1)  albIndex = intent.getIntExtra("albIndex", 0);
            currentAlbum = albumsList.get(albIndex);
            albumTextView.setText(("Album: " + currentAlbum.getAlbumName()));
            List<String> names = new ArrayList<>();
            for (Album a: albumsList)  names.add(a.getAlbumName());
            albumsUpdate(albumsList);
            photosUpdate(currentAlbum);
        }


        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), SearchActivity.class);
                if (albumsList != null && !albumsList.isEmpty()) {
                    i.putExtra("albumsList", albumsList);
                    i.putExtra("currAlbum", currentAlbum);
                    i.putExtra("albIndex", albIndex);
                }
                else {
                    i.putExtra("albumsList", new ArrayList<Album>());
                    i.putExtra("currAlbum", new Album("temp"));
                    i.putExtra("albIndex", 0);
                }

                startActivity(i);
            }
        });


        albumListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                albumListView.setItemChecked(position, true);
                albIndex = position;
                currentAlbum = albumsList.get(albIndex);

                albumTextView.setText(("Album: " + currentAlbum.getAlbumName()));
                photosUpdate(currentAlbum);
                try{
                    writePos(currAlbumFile, albIndex);
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });




    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_format, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected( MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_open)  return openAlbum();

        else if (id == R.id.action_create) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Please enter a name");

            final EditText txt = new EditText(this);

            txt.setInputType(InputType.TYPE_CLASS_TEXT);
            builder.setView(txt);

            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {@Override
                public void onClick(DialogInterface dialog, int which) {
                    String albumName = txt.getText().toString();
                    newAlbum(albumName);
                }
            });
            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.cancel();
                }
            });

            builder.show();
            return true;
        }
        else if (id == R.id.action_delete) {
            if (albumsList != null && !albumsList.isEmpty()) {

                AlertDialog.Builder b = new AlertDialog.Builder(this);
                b.setTitle("Are you sure you want to delete " + currentAlbum.getAlbumName());
                b.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        removeAlbum();
                    }
                });
                b.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                b.show();
                return true;
            }
            else {
                Snackbar.make(findViewById(R.id.mainToolBar), "You have not selected an album", Snackbar.LENGTH_LONG).setAction("Action", null).show();
            }
        }
        else if (id == R.id.action_rename) {
            if (albumsList != null && !albumsList.isEmpty()) {
                AlertDialog.Builder b = new AlertDialog.Builder(this);
                b.setTitle("Rename album");

                final EditText newName = new EditText(this);
                newName.setInputType(InputType.TYPE_CLASS_TEXT);
                b.setView(newName);

                b.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String albumName = newName.getText().toString();
                        rename(albumName);
                    }
                });
                b.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                b.show();
                return true;
            }
            else {
                Snackbar.make(findViewById(R.id.mainToolBar), "Please select an album", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }

        }

        return super.onOptionsItemSelected(item);
    }

    public int readPos(File f) throws IOException {
        Scanner s = new Scanner(f);
        String x = s.nextLine();
        int n = Integer.parseInt(x);
        s.close();
        return n;
    }

    private void albumsUpdate(List<Album> aList) {
        if (aList == null || aList.isEmpty()) {
            albumListView.setAdapter(null); return;
        }
        List<String> names = new ArrayList<>();
        for (Album a: aList) names.add(a.getAlbumName());

        ArrayAdapter<String> nameAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, names);
        nameAdapter.setNotifyOnChange(true);

        albumListView.setAdapter(nameAdapter);
        albumListView.setItemChecked(albIndex, true);
        currentAlbum = aList.get(albIndex);

        File f = new File(currentAlbumTxt);
        try{
            writePos(f, albIndex);}
        catch (IOException e) {
            e.printStackTrace();
        }
        albumTextView.setText(("Album: " + currentAlbum.getAlbumName()));
    }
    public void writePos(File f1, int p) throws IOException{
        if (f1.delete()) f1.createNewFile();
        PrintWriter pw = new PrintWriter(f1);

        pw.write((p + ""));
        pw.close();
    }
    public void photosUpdate(Album alb) {
        if (alb == null || alb.getPhotosInAlbum().size() == 0) {
            photoGridView.setAdapter(null);
            return;
        }

        PhotoAdapter adpt = new PhotoAdapter(this, R.layout.photo_adapter_layout, alb.getPhotosInAlbum());

        adpt.setNotifyOnChange(true);
        photoGridView = (GridView) findViewById(R.id.photoGridView);
        photoGridView.setAdapter(adpt);
    }

    public boolean openAlbum() {
        if (albumsList != null && !albumsList.isEmpty()) {


            Intent i = new Intent(getApplicationContext(), OpenAlbumActivity.class);
            i.putExtra("albumsList", albumsList);
            i.putExtra("currentAlbum", currentAlbum);
            i.putExtra("albIndex", albIndex);
            startActivity(i);
            return true;
        }
        else {

            Snackbar.make(findViewById(R.id.mainToolBar), "Please select an album", Snackbar.LENGTH_LONG)
                    .setAction("Action", null).show();
            return false;
        }
    }

    public void newAlbum(String name)  {
        if (albumsList != null && !albumsList.isEmpty()) {
            for (Album a: albumsList) {
                if (a.getAlbumName().equals(name)) {
                    Snackbar.make(findViewById(R.id.mainToolBar), "You already have an album with that name", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show(); return;
                }
            }
        }
        else albumsList = new ArrayList<>();

        albumsList.add(new Album(name));
        albIndex = albumsList.size() - 1;
        currentAlbum = albumsList.get(albIndex);

        albumsUpdate(albumsList);
        photoGridView.setAdapter(null);
        saveUserData(albumsList);


    }
    private void saveUserData(ArrayList<Album> a) {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(path);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(a);

            objectOutputStream.close();
            fileOutputStream.close();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public void removeAlbum() {
        albumsList.remove(currentAlbum);

        if (albumsList.size() > 0) {
            if (albIndex >= albumsList.size())  albIndex--;

            currentAlbum = albumsList.get(albIndex);

            albumsUpdate(albumsList);
            photosUpdate(currentAlbum);
        }
        else {
            albumListView.setAdapter(null);
            photoGridView.setAdapter(null);
            albumTextView.setText("Album:");
        }

        saveUserData(albumsList);
    }

    public void rename(String newName) {
        for (Album a: albumsList) {
            if (a.getAlbumName().equals(newName)) {
                Snackbar.make(findViewById(R.id.mainToolBar), "You already have an album under that name", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();return;
            }
        }

        currentAlbum.setAlbumName(newName);
        albumsUpdate(albumsList);
        saveUserData(albumsList);
    }



}