package com.example.photos64;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Instrumentation;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class OpenAlbumActivity extends AppCompatActivity {

    private Album currentAlbum;

    private ActivityResultLauncher<Intent> launcher;

    String path;

    private Photo currentPhoto;

    private int albIndex;
    private TextView albumTextView;

    private GridView photoGridView;

    private ArrayList<Album> albumsList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.open_album_layout);

        path = this.getApplicationInfo().dataDir + "/data.dat";

        Intent intent = getIntent();
        albumsList = (ArrayList<Album>) intent.getSerializableExtra("albumsList");

        albIndex = intent.getIntExtra("albIndex", 0);

        currentAlbum = albumsList.get( albIndex);

        albumTextView = (TextView) findViewById(R.id.albumNameTextView);
        albumTextView.setText(currentAlbum.getAlbumName());


        PhotoAdapter adpt = new PhotoAdapter(this, R.layout.photo_adapter_layout, currentAlbum.getPhotosInAlbum());
        adpt.setNotifyOnChange(true);
        photoGridView = (GridView) findViewById(R.id.albumPhotoGridView);

        photoGridView.setAdapter(adpt);
        if(!currentAlbum.getPhotosInAlbum().isEmpty()) {
            photoGridView.setItemChecked(0, true);
            currentPhoto = currentAlbum.getPhotosInAlbum().get(0);
        }

        photoGridView.setOnItemClickListener((parent, view, position, id) -> {
            photoGridView.setItemChecked(position, true);
            currentPhoto = currentAlbum.getPhotosInAlbum().get(position);
        });

        launcher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent data = result.getData();
                        if(result!= null) {
                            Uri uri = data.getData();
                            Bitmap bitmap = null;
                            try {
                                ParcelFileDescriptor parcelFileDescriptor = getContentResolver().openFileDescriptor(uri, "r");
                                FileDescriptor fileDescriptor = parcelFileDescriptor.getFileDescriptor();
                                bitmap = BitmapFactory.decodeFileDescriptor(fileDescriptor);
                                parcelFileDescriptor.close();
                            } catch (Exception exception) {
                                exception.printStackTrace();
                            }

                            if(bitmap!=null) {
                                String name = uri.toString();
                                Photo photo = new Photo(name);
                                for (int i = 0; i < currentAlbum.getPhotosInAlbum().size(); i++) {
                                    if (photo.getPath().equals(currentAlbum.getPhotosInAlbum().get(i).getPath())) {
                                        AlertDialog.Builder builder = new AlertDialog.Builder(this);
                                        builder.setTitle("ERROR!");
                                        builder.setMessage(name + " is already in " + currentAlbum.getAlbumName());
                                        builder.setPositiveButton("OK", null);
                                        builder.show();

                                        return;
                                    }
                                }

                                currentAlbum.addPhoto(photo);
                                currentPhoto = currentAlbum.getPhotosInAlbum().get(currentAlbum.getPhotosInAlbum().size() - 1);
                                photosUpdate(currentAlbum);

                                photoGridView.setItemChecked(currentAlbum.getPhotosInAlbum().size() - 1, true);
                                photoGridView.refreshDrawableState();
                                saveUserData(albumsList);
                            }
                        }

                    }
                });
    }

    public void goBackToHome(View v) {
        Intent i = new Intent(this, Photos.class);
        try {
            i.putExtra("albumsList", albumsList);
            i.putExtra("currentAlbum", currentAlbum);
            i.putExtra("albIndex", albIndex);
            startActivity(i);
        }
        catch (Exception e) {
            albumTextView.setTextSize(12);
            albumTextView.setText(e.toString());
        }
    }

    public void deletePhoto(View v) {
        PhotoAdapter adpt = (PhotoAdapter) photoGridView.getAdapter();
        AlertDialog.Builder b = new AlertDialog.Builder(this);

        if(adpt.getCount() == 0){
            b.setTitle("ERROR!");
            b.setMessage("This album is empty");
            b.setPositiveButton("Close", null);
            b.show();
            return;
        }

        b.setTitle("Delete Photo");
        b.setMessage("Are you sure you want to delete " + currentPhoto.getName()
                + " from " + currentAlbum.getAlbumName()+"?");
        b.setPositiveButton("Yes",
                (dialog, which) -> {
                    currentAlbum.removePhoto(currentPhoto);
                    saveUserData(albumsList);
                    photosUpdate(currentAlbum);
                    photoGridView.refreshDrawableState();

                    if(!currentAlbum.getPhotosInAlbum().isEmpty()){
                        currentPhoto = currentAlbum.getPhotosInAlbum().get(0);
                        photoGridView.setItemChecked(0, true);
                    }
                    else photoGridView.setAdapter(null);

                });

         b.setNegativeButton("No",
                 (dialog, which) -> dialog.cancel());
        b.show();

        return;
    }

    public void addPhoto(View view) {

        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");

        launcher.launch(intent);

    }


    public void movePhoto(View v) {

        if (albumsList.size() <= 1) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);builder.setTitle("ERROR!");
            builder.setMessage("You have no other albums available.");
            builder.setPositiveButton("OK", null);
            builder.show();
            return;
        }
        if (currentAlbum.getPhotosInAlbum().size() == 0) {
            AlertDialog.Builder b = new AlertDialog.Builder(this);
            b.setTitle("ERROR!");
            b.setMessage("No photos in album.");
            b.setPositiveButton("Close", null);
            b.show();
            return;
        }

        CharSequence[] albumsPossible = new CharSequence[albumsList.size()-1];

        int value = 0;

        for(Album a: albumsList){
            if(!a.getAlbumName().equals(currentAlbum.getAlbumName())) {
                albumsPossible[value] = a.getAlbumName();
                value++;
            }
        }

        AlertDialog.Builder b = new AlertDialog.Builder(this);
        final String[] moveToAlbum = {albumsPossible[0].toString()};

        b.setSingleChoiceItems(albumsPossible, 0, (dialog, item) -> moveToAlbum[0] = albumsPossible[item].toString());

        b.setPositiveButton("Move",
                (dialog, item) -> {
                    for(Album a : albumsList){
                        if(a.getAlbumName().equals(moveToAlbum[0])){
                            Album newAlbum = a;
                            for(Photo p: newAlbum.photosInAlbum){
                                if(currentPhoto.getPath().equals(p.getPath())){
                                    b.setTitle("ERROR!");
                                    b.setMessage("Photo is already in " + moveToAlbum[0]);
                                    b.setPositiveButton("OK", null);
                                    b.show();

                                    return;
                                }
                            }

                            newAlbum.addPhoto(currentPhoto);
                            currentAlbum.removePhoto(currentPhoto);
                            photosUpdate(currentAlbum);
                            saveUserData(albumsList);
                        }
                    }
                });
        b.setNegativeButton("Cancel",
                (dialog, which) -> dialog.cancel());
        b.show();
        return;
    }

    public void displayPhoto(View v) {
        if (currentAlbum.getPhotosInAlbum().size() == 0) {
            AlertDialog.Builder b = new AlertDialog.Builder(this);

            b.setTitle("ERROR!");
            b.setMessage("No photos in this album");
            b.setPositiveButton("Close", null);
            b.show();

            return;
        }
        Intent i = new Intent(this, DisplayPhotoActivity.class);

        i.putExtra("albumsList", albumsList);
        i.putExtra("currentAlbum", currentAlbum);
        i.putExtra("albIndex", albIndex);
        i.putExtra("currentPhoto", currentPhoto);

        int position = 0;
        for (int x = 0; x < currentAlbum.getPhotosInAlbum().size(); x++) {
            if (currentPhoto.equals(currentAlbum.getPhotosInAlbum().get(x))) {
                position = x;
                break;
            }
        }

        i.putExtra("position", position);
        startActivity(i);


    }



    public void saveUserData(ArrayList<Album> a) {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(path);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);

            objectOutputStream.writeObject(a);

            objectOutputStream.close();
            fileOutputStream.close();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }


    public void photosUpdate(Album a) {
        if (a == null || (a.getPhotosInAlbum() == null || a.getPhotosInAlbum().size() == 0)) {
            photoGridView.setAdapter(null);return;
        }
        PhotoAdapter adpt = new PhotoAdapter(this, R.layout.photo_adapter_layout, a.getPhotosInAlbum());
        adpt.setNotifyOnChange(true);
        photoGridView = findViewById(R.id.albumPhotoGridView);
        photoGridView.setAdapter(adpt);
    }


}