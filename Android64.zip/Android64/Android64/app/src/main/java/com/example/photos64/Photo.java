package com.example.photos64;
import java.util.ArrayList;
import java.io.Serializable;
import java.util.*;

/**
 * Photo object representation
 */
public class Photo implements Serializable{
    private static final long serialVersionUID = 42L;

    //list of tags for this photo
    private List<Tag> tagList;

    private String name;


    //path for the file of this photo
     String path;

    //no args constructor if necessary
    public Photo(String path) {
        tagList = new ArrayList<Tag>();

        this.path = path;
        if (path.contains("/")) this.name = path.substring(path.lastIndexOf('/') + 1);
        else name = path;

    }
    public String getName() {return name;}

    public String getPath() {return path;}
    public List<Tag> getTagList() {return tagList;}

    public Tag findTag(String type, String value) {
        Tag found = new Tag(type,value,false);
        for(Tag t: tagList) {
            if(t.equals(found)) return t;
        }
        return null;
    }

    public void addNewTag(Tag addTag) {
        for(Tag t: tagList) {
            if (addTag.getType().equals(t.getType()) && !t.getMultiple()) return;
            if (addTag.equals(t) ) return;
        }
        tagList.add(addTag);
    }
    public boolean equals(Photo p) {
        return this.path.equals(p.getPath());
    }
    public void removeTag(String type, String value) {
        for(Tag t: tagList) {
            if(findTag(type, value).equals(t)) tagList.remove(t);
        }
    }



}
